# Como colocar o app no seu GitHub

Repositório: **https://github.com/shalomvariedades2222-cell/pdv-sistem**

O site (HTML) já está na pasta raiz. O app Android vai numa pasta `android/` no mesmo repo.

---

## Opção A — Pelo site do GitHub (mais fácil)

### 1. Subir a pasta do app
1. Abra: https://github.com/shalomvariedades2222-cell/pdv-sistem
2. Clique em **Add file → Upload files**
3. Arraste a pasta **SLMsys-Kotlin** inteira (ou renomeie para `android` antes)
4. Commit message: `App Android SLMsys 1.1.0`
5. **Commit changes**

### 2. Publicar o APK (atualização no celular)
1. No Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Pegue o arquivo: `app/build/outputs/apk/debug/app-debug.apk`
3. No GitHub: **Releases** (menu da direita) → **Create a new release**
4. **Choose a tag**: digite `v1.1.0` → Create new tag
5. Release title: `SLMsys Android 1.1.0`
6. Em **Attach binaries**: arraste o `app-debug.apk`
7. **Publish release**

### 3. No celular
**Ajustes → Procurar atualização no GitHub**  
Se a versão do Release for maior que a instalada, aparece **Baixar versão …**

---

## Opção B — Pelo terminal (git)

```bash
# clone o repo (se ainda não tiver)
git clone https://github.com/shalomvariedades2222-cell/pdv-sistem.git
cd pdv-sistem

# copie o projeto Android para a pasta android/
# (no Windows: copie a pasta SLMsys-Kotlin para dentro de pdv-sistem e renomeie para android)

git add android
git commit -m "App Android SLMsys 1.1.0"
git push origin main
```

Depois faça o **Release** com o APK (passo 2 da Opção A).

---

## Próximas versões

1. Gere o APK e publique um **novo Release** no GitHub (tag qualquer, ex.: `v1.2.4`) com o APK anexado.
2. Nos aparelhos: abra o app (o popup aparece sozinho) ou Ajustes → Procurar atualização.

**Não precisa mais mexer na versão dentro do app.** O app calcula a impressão digital (SHA-256)
do próprio APK e compara com os APKs dos Releases do GitHub, então sabe exatamente qual
versão está instalada. `versionCode` é automático; `versionName` no `build.gradle.kts` é só um rótulo.

**Dica:** instale no aparelho o MESMO arquivo que você anexou no Release (ou instale pelo
próprio popup). Se instalar um APK diferente do que está no Release, o app vai avisar de novo
uma vez — ele nunca entra em loop, porque depois de instalar pelo popup o APK passa a ser idêntico ao do Release.

O app já está configurado com:
`GITHUB_REPO = "shalomvariedades2222-cell/pdv-sistem"`
