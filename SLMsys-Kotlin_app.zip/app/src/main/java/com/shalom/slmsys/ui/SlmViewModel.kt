package com.shalom.slmsys.ui

import android.Manifest
import android.app.Application
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shalom.slmsys.data.Customer
import com.shalom.slmsys.data.CustomerDraft
import com.shalom.slmsys.data.PrintJob
import com.shalom.slmsys.data.Product
import com.shalom.slmsys.data.ProductDraft
import com.shalom.slmsys.data.Repository
import com.shalom.slmsys.data.StoreSettings
import com.shalom.slmsys.util.AppUpdateChecker
import com.shalom.slmsys.util.AppUpdateInstaller
import com.shalom.slmsys.printer.BlePrinter
import com.shalom.slmsys.printer.EscPos
import com.shalom.slmsys.util.parseMoney
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

enum class AppView { ESTOQUE, MOVIMENTOS, CLIENTES, IMPRESSORA, AJUSTES }
enum class PrinterStatus { DISCONNECTED, SCANNING, CONNECTING, READY, PRINTING, ERROR }

data class UiState(
    val loggedIn: Boolean = false,
    val checkingAuth: Boolean = true,
    val view: AppView = AppView.ESTOQUE,
    val products: List<Product> = emptyList(),
    val customers: List<Customer> = emptyList(),
    val categories: List<com.shalom.slmsys.data.Category> = emptyList(),
    val movements: List<com.shalom.slmsys.data.Movement> = emptyList(),
    val printJobs: List<PrintJob> = emptyList(),
    val settings: StoreSettings = StoreSettings(),
    val productNames: List<String> = emptyList(),
    val sizes: List<String> = emptyList(),
    val colors: List<String> = emptyList(),
    val labelModels: List<String> = emptyList(),
    val query: String = "",
    val categoryFilter: String = "",
    val customerQuery: String = "",
    val movementFilter: String = "", // "" | entrada | saida
    val printerStatus: PrinterStatus = PrinterStatus.DISCONNECTED,
    val printerName: String = "",
    val printerError: String = "",
    /** true = a conexão automática com a última impressora passou de ~6s (ou falhou):
     * mostra o aviso "desligue e ligue a impressora / o Bluetooth". */
    val printerSlowWarning: Boolean = false,
    val busy: Boolean = false,
    val syncing: Boolean = false,
    /** Texto do "popup" de salvamento (canto da tela, não bloqueia), igual ao
     * indicador "Salvando arquivo no servidor..." do site. Null = escondido. */
    val savingLabel: String? = null,
    val editingLabel: Boolean = false,
    val updateAvailable: Boolean = false,
    val updateTag: String = "",
    val updateApkUrl: String = "",
    val updateReleaseId: Long = 0L,
    val updateReason: String = "",
    val updateMessage: String? = null,
    /** null = não está baixando; -1 = baixando (tamanho desconhecido); 0..100 = progresso. */
    val updateDownloadProgress: Int? = null,
    /** Caminho do APK já baixado, pronto para instalar (null = ainda não baixou). */
    val updateReadyPath: String? = null,
    /** Janela "Instalar agora?" visível. */
    val updateDialogVisible: Boolean = false,
    val message: String? = null,
    val loginError: String? = null,
    val accessRequestId: String? = null,
    val accessStatus: String? = null,
    /** Se este aparelho está com internet agora (detectado de verdade pelo sistema,
     * igual ao evento online/offline do navegador no site). */
    val online: Boolean = true,
    /** Quantas alterações feitas offline ainda não subiram pro servidor. */
    val pendingCount: Int = 0,
    /** Notificação chamativa de conexão na parte de baixo da tela — "ficou offline"
     * / "voltou a internet" — igual ao #connNotify do site. Null = escondida. */
    val connBannerText: String? = null,
    val connBannerKind: String = "offline", // "offline" | "online"
    /** URL do servidor (Apps Script) configurada neste aparelho — mostrada/editável
     * na tela de login. Configurada uma vez; fica salva no banco local. */
    val serverUrl: String = ""
)

class SlmViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    private val ble = BlePrinter(app)
    private var pollJob: Job? = null

    private val _loggedIn = MutableStateFlow(false)
    private val _checkingAuth = MutableStateFlow(true)
    private val _view = MutableStateFlow(AppView.ESTOQUE)
    private val _query = MutableStateFlow("")
    private val _categoryFilter = MutableStateFlow("")
    private val _customerQuery = MutableStateFlow("")
    private val _movementFilter = MutableStateFlow("")
    private val _printerStatus = MutableStateFlow(PrinterStatus.DISCONNECTED)
    private val _printerName = MutableStateFlow("")
    private val _printerError = MutableStateFlow("")
    private val _printerSlowWarning = MutableStateFlow(false)
    private val _updateProgress = MutableStateFlow<Int?>(null)
    private val _updateReadyPath = MutableStateFlow<String?>(null)
    private val _updateDialog = MutableStateFlow(false)
    private var updateDownloadJob: Job? = null
    private val prefs = app.getSharedPreferences("slmsys_prefs", Context.MODE_PRIVATE)
    private var autoConnectJob: Job? = null
    private var autoConnectDone = false
    private val _busy = MutableStateFlow(false)
    private val _syncing = MutableStateFlow(false)
    private val _savingLabel = MutableStateFlow<String?>(null)
    private val _editingLabel = MutableStateFlow(false)
    private val _updateAvailable = MutableStateFlow(false)
    private val _updateTag = MutableStateFlow("")
    private val _updateApkUrl = MutableStateFlow("")
    private val _updateReleaseId = MutableStateFlow(0L)
    private val productSaveMutex = Mutex()
    private val _updateReason = MutableStateFlow("")
    private val _updateMessage = MutableStateFlow<String?>(null)
    private val _message = MutableStateFlow<String?>(null)
    private val _loginError = MutableStateFlow<String?>(null)
    private val _accessRequestId = MutableStateFlow<String?>(null)
    private val _accessStatus = MutableStateFlow<String?>(null)
    private val _online = MutableStateFlow(true)
    private val _pendingCount = MutableStateFlow(0)
    private val _connBannerText = MutableStateFlow<String?>(null)
    private val _connBannerKind = MutableStateFlow("offline")
    private val _serverUrl = MutableStateFlow("")
    private var bannerJob: Job? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null

    // Combine in smaller groups to avoid 22-arg combine limits / cast hell
    private data class Bag1(
        val loggedIn: Boolean,
        val checkingAuth: Boolean,
        val view: AppView,
        val products: List<Product>,
        val customers: List<Customer>
    )
    private data class Bag2(
        val categories: List<com.shalom.slmsys.data.Category>,
        val movements: List<com.shalom.slmsys.data.Movement>,
        val printJobs: List<PrintJob>,
        val settings: StoreSettings,
        val productNames: List<String>
    )
    private data class Bag3(
        val sizes: List<String>,
        val colors: List<String>,
        val labelModels: List<String>,
        val query: String,
        val categoryFilter: String
    )
    private data class Bag4(
        val customerQuery: String,
        val movementFilter: String,
        val printerStatus: PrinterStatus,
        val printerName: String,
        val printerError: String
    )
    private data class Bag5(
        val busy: Boolean,
        val syncing: Boolean,
        val message: String?,
        val loginError: String?,
        val accessRequestId: String?,
        val savingLabel: String?
    )

    private val bag1 = combine(_loggedIn, _checkingAuth, _view, repo.products, repo.customers) {
            a, b, c, d, e -> Bag1(a, b, c, d, e)
    }
    private val bag2 = combine(repo.categories, repo.movements, repo.printJobs, repo.settings, repo.productNames) {
            a, b, c, d, e -> Bag2(a, b, c, d, e)
    }
    private val bag3 = combine(repo.sizes, repo.colors, repo.labelModels, _query, _categoryFilter) {
            a, b, c, d, e -> Bag3(a, b, c, d, e)
    }
    private val bag4 = combine(_customerQuery, _movementFilter, _printerStatus, _printerName, _printerError) {
            a, b, c, d, e -> Bag4(a, b, c, d, e)
    }
    private val bag5a = combine(_busy, _syncing, _message, _loginError, _accessRequestId) {
            a, b, c, d, e -> listOf(a, b, c, d, e)
    }
    private val bag5 = combine(bag5a, _savingLabel) { list, f ->
        @Suppress("UNCHECKED_CAST")
        Bag5(
            busy = list[0] as Boolean,
            syncing = list[1] as Boolean,
            message = list[2] as String?,
            loginError = list[3] as String?,
            accessRequestId = list[4] as String?,
            savingLabel = f
        )
    }
    private val bags = combine(bag1, bag2, bag3, bag4, bag5) { b1, b2, b3, b4, b5 ->
        listOf(b1, b2, b3, b4, b5)
    }

    private data class Bag6(
        val online: Boolean,
        val pendingCount: Int,
        val connBannerText: String?,
        val connBannerKind: String,
        val serverUrl: String
    )
    private val bag6 = combine(_online, _pendingCount, _connBannerText, _connBannerKind, _serverUrl) {
            a, b, c, d, e -> Bag6(a, b, c, d, e)
    }

    private data class Bag7(
        val editingLabel: Boolean,
        val updateAvailable: Boolean,
        val updateTag: String,
        val updateApkUrl: String,
        val updateMessage: String?
    )
    private val bag7 = combine(
        _editingLabel, _updateAvailable, _updateTag, _updateApkUrl, _updateMessage
    ) { a, b, c, d, e -> Bag7(a, b, c, d, e) }

    private data class Bag8(
        val printerSlowWarning: Boolean,
        val updateProgress: Int?,
        val updateReadyPath: String?,
        val updateDialog: Boolean
    )
    private val bag8 = combine(
        _printerSlowWarning, _updateProgress, _updateReadyPath, _updateDialog
    ) { a, b, c, d -> Bag8(a, b, c, d) }

    val uiState: StateFlow<UiState> = combine(bags, _accessStatus, bag6, bag7, bag8) { list, accessStatus, b6, b7, b8 ->
        val b1 = list[0] as Bag1
        val b2 = list[1] as Bag2
        val b3 = list[2] as Bag3
        val b4 = list[3] as Bag4
        val b5 = list[4] as Bag5
        UiState(
            loggedIn = b1.loggedIn,
            checkingAuth = b1.checkingAuth,
            view = b1.view,
            products = b1.products,
            customers = b1.customers,
            categories = b2.categories,
            movements = b2.movements,
            printJobs = b2.printJobs,
            settings = b2.settings,
            productNames = b2.productNames,
            sizes = b3.sizes,
            colors = b3.colors,
            labelModels = b3.labelModels,
            query = b3.query,
            categoryFilter = b3.categoryFilter,
            customerQuery = b4.customerQuery,
            movementFilter = b4.movementFilter,
            printerStatus = b4.printerStatus,
            printerName = b4.printerName,
            printerError = b4.printerError,
            printerSlowWarning = b8.printerSlowWarning,
            updateDownloadProgress = b8.updateProgress,
            updateReadyPath = b8.updateReadyPath,
            updateDialogVisible = b8.updateDialog,
            busy = b5.busy,
            syncing = b5.syncing,
            savingLabel = b5.savingLabel,
            editingLabel = b7.editingLabel,
            updateAvailable = b7.updateAvailable,
            updateTag = b7.updateTag,
            updateApkUrl = b7.updateApkUrl,
            updateMessage = b7.updateMessage,
            message = b5.message,
            loginError = b5.loginError,
            accessRequestId = b5.accessRequestId,
            accessStatus = accessStatus,
            online = b6.online,
            pendingCount = b6.pendingCount,
            connBannerText = b6.connBannerText,
            connBannerKind = b6.connBannerKind,
            serverUrl = b6.serverUrl
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    init {
        viewModelScope.launch {
            // 1) Entra rápido com dados locais — não trava na tela preta de boot
            repo.applyStoredServerUrl()
            _serverUrl.value = "" // oculto na UI
            val auth = repo.getAuth()
            if (auth.accessKey.isNotBlank() || auth.deviceToken.isNotBlank()) {
                repo.reloadCatalogFromLocal()
                _loggedIn.value = true
                _checkingAuth.value = false
                // 2) Conecta ao servidor em background (com tentativas + animação)
                connectToServerInBackground(initial = true)
            } else {
                _checkingAuth.value = false
            }
        }
        // Procura atualização UMA vez por abertura do app, em silêncio (sem pill, sem aviso).
        checkAppUpdateSilently()
        startAutoSyncLoop()
        viewModelScope.launch { repo.pendingCount.collect { _pendingCount.value = it } }
        registerConnectivity()
    }

    /**
     * Tenta sincronizar com o servidor sem bloquear a UI.
     * Mostra "Conectando ao servidor…" com o pill animado e re-tenta se falhar.
     */
    private fun connectToServerInBackground(initial: Boolean = false) {
        viewModelScope.launch {
            if (_syncing.value) return@launch
            _syncing.value = true
            _savingLabel.value = "Conectando ao servidor…"
            var lastError: String? = null
            val attempts = if (initial) 4 else 2
            for (attempt in 1..attempts) {
                _savingLabel.value = if (attempt == 1) {
                    "Conectando ao servidor…"
                } else {
                    "Reconectando ao servidor… ($attempt/$attempts)"
                }
                val r = repo.syncFromCloud()
                if (r.isSuccess) {
                    val n = r.getOrNull()?.products?.size ?: 0
                    val c = r.getOrNull()?.customers?.size ?: 0
                    _savingLabel.value = null
                    _syncing.value = false
                    if (initial || attempt > 1) {
                        _message.value = "Conectado · $n produtos · $c clientes"
                    }
                    return@launch
                }
                lastError = r.exceptionOrNull()?.message
                repo.reloadCatalogFromLocal()
                if (attempt < attempts) {
                    kotlinx.coroutines.delay(1500L * attempt)
                }
            }
            _savingLabel.value = null
            _syncing.value = false
            // Offline: app continua com cache local; não força logout
            if (initial) {
                showConnBanner(
                    lastError?.takeIf { it.isNotBlank() }
                        ?: "Sem conexão. Usando dados deste aparelho.",
                    "offline"
                )
            }
        }
    }

    /**
     * Fica de olho na internet do aparelho de verdade (via ConnectivityManager),
     * igual aos eventos 'offline'/'online' do navegador no site: mostra a
     * notificação chamativa embaixo da tela e, assim que a conexão volta,
     * despeja automaticamente tudo que ficou pendente no servidor.
     */
    private fun registerConnectivity() {
        val cm = getApplication<Application>()
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        _online.value = cm.activeNetwork != null

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val wasOffline = !_online.value
                _online.value = true
                if (wasOffline) {
                    showConnBanner("De volta à internet. Reconectando…", "online")
                    connectToServerInBackground(initial = false)
                    viewModelScope.launch { flushPendingOps() }
                }
            }

            override fun onLost(network: Network) {
                // só marca offline se não sobrou nenhuma outra rede ativa
                if (cm.activeNetwork == null) {
                    _online.value = false
                    showConnBanner("Você está offline. Os dados continuam salvos neste aparelho.", "offline")
                }
            }
        }
        connectivityCallback = callback
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        cm.registerNetworkCallback(request, callback)
    }

    private fun showConnBanner(text: String, kind: String) {
        bannerJob?.cancel()
        _connBannerText.value = text
        _connBannerKind.value = kind
        bannerJob = viewModelScope.launch {
            delay(7000)
            _connBannerText.value = null
        }
    }

    fun dismissConnBanner() {
        bannerJob?.cancel()
        _connBannerText.value = null
    }

    /**
     * Reenvia pro servidor tudo que foi salvo neste aparelho enquanto estava
     * offline. Usa só o popup de topo (savingLabel) — não bloqueia a tela.
     */
    private suspend fun flushPendingOps() {
        _savingLabel.value = "Enviando alterações pendentes ao servidor…"
        val result = repo.flushPendingOps()
        _savingLabel.value = null
        _message.value = when {
            result.sent == 0 && result.remaining == 0 -> return
            result.remaining == 0 -> "Tudo sincronizado · ${result.sent} pendência(s) enviada(s)"
            result.sent > 0 -> "${result.sent} enviada(s) · ${result.remaining} ainda pendente(s)"
            else -> "Ainda sem conseguir enviar ao servidor · ${result.remaining} pendente(s)"
        }
        if (result.remaining == 0 && result.sent > 0) {
            repo.syncFromCloud()
        }
    }

    override fun onCleared() {
        super.onCleared()
        connectivityCallback?.let { cb ->
            val cm = getApplication<Application>()
                .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            try { cm?.unregisterNetworkCallback(cb) } catch (_: Exception) { }
        }
    }

    /**
     * Sincronização automática em segundo plano.
     * Liga/desliga e intervalo (segundos) em Ajustes.
     * Quando desligada, só sincroniza quando o usuário pedir manualmente.
     */
    private fun startAutoSyncLoop() {
        viewModelScope.launch {
            while (isActive) {
                val settings = uiState.value.settings
                val seconds = settings.syncIntervalSec.coerceIn(10, 3600)
                delay(seconds * 1000L)
                if (!settings.autoSyncEnabled) continue
                if (_loggedIn.value && !_syncing.value && !_busy.value) {
                    // silencioso: não mostra toast em falha automática
                    repo.syncFromCloud()
                }
            }
        }
    }

    /**
     * Login com a chave de acesso. [serverUrl] é gravado no aparelho antes de
     * conectar — configuração feita uma única vez; nas próximas aberturas do
     * app o valor salvo é usado automaticamente (ver [applyStoredServerUrl]
     * no init). Deixar em branco mantém/volta pro servidor padrão do app.
     */
    fun loginWithKey(key: String, serverUrl: String = "") {
        viewModelScope.launch {
            _loginError.value = null
            val k = key.trim()
            if (k.isBlank()) {
                _loginError.value = "Informe a chave de acesso"
                return@launch
            }
            _busy.value = true
            try {
                if (serverUrl.trim().isNotBlank()) {
                    repo.saveServerUrl(serverUrl.trim())
                }
                repo.applyStoredServerUrl()
                // Grava a chave cedo — mesmo se a rede falhar, não pede de novo à toa
                repo.saveAuth(key = k)
                _serverUrl.value = ""
                val r = repo.syncFromCloud(key = k)
                if (r.isSuccess) {
                    _loggedIn.value = true
                    _accessRequestId.value = null
                    val n = r.getOrNull()?.products?.size ?: 0
                    val c = r.getOrNull()?.customers?.size ?: 0
                    val names = repo.productNames.value.size
                    _message.value = "Conectado · $n produtos · $c clientes · $names nomes no catálogo"
                } else {
                    val err = r.exceptionOrNull()?.message ?: "Falha ao conectar"
                    _loginError.value = when {
                        err.contains("chave", true) || err.contains("permiss", true) ||
                            err.contains("acesso", true) || err.contains("invalid", true) ->
                            "Chave inválida ou sem acesso. Confira a chave do site."
                        err.contains("HTML", true) ->
                            "Servidor não respondeu. Verifique a URL / internet."
                        err.contains("Unable to resolve", true) || err.contains("Failed to connect", true) ||
                            err.contains("timeout", true) || err.contains("UnknownHost", true) ->
                            "Sem internet ou servidor inacessível. Tente de novo."
                        else -> err
                    }
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun requestDeviceAccess(serverUrl: String = "") {
        viewModelScope.launch {
            _loginError.value = null
            _busy.value = true
            if (serverUrl.trim().isNotBlank()) {
                repo.saveServerUrl(serverUrl.trim())
            }
            repo.applyStoredServerUrl()
            _serverUrl.value = ""
            val r = repo.requestAccess()
            _busy.value = false
            if (r.isFailure) {
                _loginError.value = r.exceptionOrNull()?.message
                return@launch
            }
            _accessRequestId.value = r.getOrNull()
            _accessStatus.value = "pendente"
            startPolling(r.getOrNull()!!)
        }
    }

    private fun startPolling(requestId: String) {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                delay(5000)
                val r = repo.pollAccess(requestId)
                if (r.isFailure) continue
                val st = r.getOrNull()!!
                _accessStatus.value = st.status
                when (st.status) {
                    "aceito" -> {
                        _loggedIn.value = true
                        _accessRequestId.value = null
                        _message.value = "Acesso autorizado"
                        break
                    }
                    "recusado" -> {
                        _loginError.value = "Pedido recusado"
                        break
                    }
                }
            }
        }
    }

    fun cancelAccessRequest() {
        pollJob?.cancel()
        _accessRequestId.value = null
        _accessStatus.value = null
    }

    fun logout() {
        viewModelScope.launch {
            pollJob?.cancel()
            repo.clearAuth()
            _loggedIn.value = false
        }
    }

    fun refreshFromCloud() {
        viewModelScope.launch {
            _syncing.value = true
            _savingLabel.value = "Conectando ao servidor…"
            val r = repo.syncFromCloud()
            _syncing.value = false
            _savingLabel.value = null
            if (r.isSuccess) {
                _message.value = "Atualizado · ${r.getOrNull()?.products?.size ?: 0} produtos · ${r.getOrNull()?.customers?.size ?: 0} clientes"
            } else {
                _message.value = r.exceptionOrNull()?.message ?: "Falha ao atualizar"
            }
        }
    }

    fun setView(v: AppView) { _view.value = v }
    fun setQuery(q: String) { _query.value = q }
    fun setCategoryFilter(c: String) { _categoryFilter.value = c }
    fun setCustomerQuery(q: String) { _customerQuery.value = q }
    fun setMovementFilter(f: String) { _movementFilter.value = f }
    fun clearMessage() { _message.value = null }

    fun upsertProduct(draft: ProductDraft, editingId: String? = null) {
        viewModelScope.launch {
            if (editingId != null) {
                val existing = repo.getProduct(editingId) ?: return@launch
                val updated = existing.copy(
                    nome = draft.nome.trim(),
                    categoria = draft.categoria.trim(),
                    tamanho = draft.tamanho.trim(),
                    cor = draft.cor.trim(),
                    custo = parseMoney(draft.custo),
                    venda = parseMoney(draft.venda),
                    estoque = draft.estoque.toIntOrNull() ?: existing.estoque,
                    estoqueMin = draft.estoqueMin.toIntOrNull() ?: existing.estoqueMin
                )
                // Antes só gravava no aparelho; agora salva local e também no
                // servidor (com fila de pendências se estiver sem internet) —
                // igual ao cadastro novo, para nunca ficar diferente do site.
                _savingLabel.value = "Salvando..."
                val result = repo.updateProductAndSync(updated)
                _savingLabel.value = null
                val outcome = result.getOrNull()
                _message.value = when {
                    outcome == null -> result.exceptionOrNull()?.message ?: "Falha ao salvar"
                    outcome.offline -> "Produto atualizado neste aparelho · NÃO chegou ao servidor" +
                        (outcome.error?.let { " ($it)" } ?: "") + " · será reenviado automaticamente"
                    else -> "Produto atualizado e sincronizado com o servidor"
                }
                return@launch
            }

            // Cadastro novo: códigos únicos. Em lotes de até 2:
            // imprime o lote → salva o lote no servidor → próximo lote.
            // Se outro cadastro estiver salvando, espera a fila terminar.
            productSaveMutex.withLock {
            val qty = (draft.labelQty.toIntOrNull() ?: 1).coerceIn(1, 99)
            val settings = repo.getSettingsOnce()
            var saved = 0
            var printed = 0
            var lastBarcode = ""
            var lastError: String? = null
            val batchSize = 2

            var index = 0
            while (index < qty) {
                val batchCount = minOf(batchSize, qty - index)
                val batch = mutableListOf<com.shalom.slmsys.data.Product>()

                // 1) Monta os produtos do lote (códigos diferentes)
                for (b in 0 until batchCount) {
                    val itemDraft = draft.copy(
                        barcode = "",
                        labelQty = "1",
                        estoque = if (qty > 1) "1" else draft.estoque
                    )
                    val prepared = repo.prepareNewProduct(itemDraft)
                    if (prepared == null) {
                        lastError = "Não conectado ao servidor"
                        break
                    }
                    batch += prepared
                    lastBarcode = prepared.barcode
                }
                if (batch.isEmpty()) break

                // 2) Imprime todos do lote primeiro
                if (ble.isConnected) {
                    for ((bi, prepared) in batch.withIndex()) {
                        val n = index + bi + 1
                        _printerStatus.value = PrinterStatus.PRINTING
                        _savingLabel.value = "Imprimindo $n/$qty…"
                        val bytes = if (settings.protocol == "tspl") {
                            EscPos.buildTsplLabel(prepared, settings, 1)
                        } else {
                            EscPos.buildLabel(prepared, settings, 1)
                        }
                        val printResult = ble.write(bytes, settings.printSpeed)
                        repo.insertPrintJob(
                            PrintJob(
                                id = UUID.randomUUID().toString(),
                                productId = prepared.id,
                                productName = prepared.nome,
                                barcode = prepared.barcode,
                                qty = 1,
                                ok = printResult.isSuccess,
                                mode = "bluetooth",
                                at = System.currentTimeMillis()
                            )
                        )
                        if (printResult.isSuccess) {
                            printed++
                            _printerStatus.value = PrinterStatus.READY
                            delay(250)
                        } else {
                            _printerStatus.value = PrinterStatus.ERROR
                            _printerError.value = printResult.exceptionOrNull()?.message ?: "Erro"
                            lastError = "Falha na impressão item $n: ${_printerError.value}"
                            batch.clear()
                            break
                        }
                    }
                }

                if (lastError != null && batch.isEmpty()) break

                // 3) Só depois salva o lote no servidor
                for ((bi, prepared) in batch.withIndex()) {
                    val n = index + bi + 1
                    _savingLabel.value = "Salvando $n/$qty no servidor…"
                    val result = repo.persistNewProduct(prepared, draft)
                    if (result.getOrNull() != null) {
                        saved++
                    } else {
                        lastError = result.exceptionOrNull()?.message ?: "Falha ao salvar item $n"
                        break
                    }
                }

                if (lastError != null && saved < index + batch.size) break
                index += batch.size
            }

            _savingLabel.value = null
            _message.value = when {
                saved == 0 && lastError != null -> lastError!!
                saved == qty && printed == qty ->
                    "OK · $saved itens impressos e salvos (códigos diferentes)"
                saved == qty && printed == 0 ->
                    "OK · $saved itens salvos · conecte a impressora para etiquetas"
                saved == qty ->
                    "OK · $saved salvos · $printed impressos · último cód. $lastBarcode"
                else ->
                    "Parcial: $saved/$qty salvos · $printed impressos" +
                        (lastError?.let { " · $it" } ?: "")
            }
            } // productSaveMutex
        }
    }

    /**
     * Cadastra na hora uma categoria ou nome que ainda não existe no catálogo,
     * chamado pelo botão "Cadastrar categoria/nome" da tela de cadastro de peça
     * quando o texto digitado não bate com nada da lista. Não bloqueia a tela;
     * funciona sem internet e sincroniza depois.
     */
    fun registerCatalogEntry(type: String, value: String, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            if (value.isBlank()) {
                onDone(false)
                return@launch
            }
            _savingLabel.value = "Salvando..."
            val r = repo.registerCatalogEntry(type, value)
            _savingLabel.value = null
            if (r.isSuccess) {
                val outcome = r.getOrNull()!!
                val nomeCampo = if (type == "categoria") "Categoria" else "Nome"
                _message.value = if (outcome.offline) {
                    "$nomeCampo salvo neste aparelho (sem internet): ${outcome.value}"
                } else {
                    "$nomeCampo cadastrado: ${outcome.value}"
                }
                onDone(true)
            } else {
                _message.value = r.exceptionOrNull()?.message ?: "Falha ao cadastrar"
                onDone(false)
            }
        }
    }

    fun deleteProduct(id: String) {
        viewModelScope.launch {
            _busy.value = true
            _savingLabel.value = "Excluindo..."
            val r = repo.deleteProductAndSync(id)
            _busy.value = false
            _savingLabel.value = null
            _message.value = if (r.isSuccess) "Excluído do servidor" else
                "Falha: ${r.exceptionOrNull()?.message}"
        }
    }

    fun saveCustomer(draft: CustomerDraft) {
        viewModelScope.launch {
            if (draft.nome.isBlank()) {
                _message.value = "Informe o nome do cliente"
                return@launch
            }
            // não bloqueia a tela — só o popup de topo; funciona sem internet.
            _savingLabel.value = "Salvando..."
            val r = repo.createCustomerAndSync(draft)
            _savingLabel.value = null
            if (r.isSuccess) {
                val outcome = r.getOrNull()!!
                _message.value = if (outcome.offline) {
                    "Cliente salvo neste aparelho · será enviado quando a internet voltar"
                } else {
                    "Cliente salvo no servidor"
                }
            } else {
                _message.value = r.exceptionOrNull()?.message ?: "Falha ao salvar cliente"
            }
        }
    }

    fun adjustStock(productId: String, kind: String, qty: Int, note: String) {
        viewModelScope.launch {
            if (qty <= 0) return@launch
            repo.adjustStock(productId, kind, qty, note)
            _message.value = if (kind == "entrada") "Entrada +$qty" else "Saída −$qty"
        }
    }

    fun updateSettings(patch: StoreSettings) {
        viewModelScope.launch {
            repo.updateSettings(patch)
            _message.value = "Ajustes salvos"
        }
    }

    fun connectToDevice(device: BluetoothDevice) {
        // Se a conexão automática ainda estiver em andamento, a escolha manual vence.
        autoConnectJob?.cancel()
        _printerSlowWarning.value = false
        viewModelScope.launch {
            _busy.value = true
            _savingLabel.value = "Conectando à impressora..."
            _printerStatus.value = PrinterStatus.CONNECTING
            _printerError.value = ""
            val result = ble.connect(device)
            if (result.isSuccess) {
                _printerStatus.value = PrinterStatus.READY
                _printerName.value = ble.deviceName
                saveLastPrinter(ble.deviceAddress, ble.deviceName)
                _message.value = "Impressora pronta"
            } else {
                _printerStatus.value = PrinterStatus.ERROR
                _printerError.value = result.exceptionOrNull()?.message ?: "Falha"
            }
            _busy.value = false
            _savingLabel.value = null
        }
    }

    fun disconnectPrinter() {
        ble.disconnect()
        _printerStatus.value = PrinterStatus.DISCONNECTED
        _printerName.value = ""
        _message.value = "Impressora desconectada"
    }

    fun printProduct(productId: String, qty: Int) {
        viewModelScope.launch {
            val product = repo.getProduct(productId) ?: run {
                _message.value = "Produto não encontrado"
                return@launch
            }
            if (!ble.isConnected) {
                _message.value = "Conecte a impressora em Impressora"
                return@launch
            }
            _busy.value = true
            _savingLabel.value = "Imprimindo etiqueta..."
            _printerStatus.value = PrinterStatus.PRINTING
            // Layout do designer (etiquetaModelos) vem do servidor via settings
            val settings = repo.getSettingsOnce()
            val bytes = if (settings.protocol == "tspl") {
                EscPos.buildTsplLabel(product, settings, qty)
            } else {
                EscPos.buildLabel(product, settings, qty)
            }
            val result = ble.write(bytes, settings.printSpeed)
            repo.insertPrintJob(
                PrintJob(
                    id = UUID.randomUUID().toString(),
                    productId = product.id,
                    productName = product.nome,
                    barcode = product.barcode,
                    qty = qty,
                    ok = result.isSuccess,
                    mode = "bluetooth",
                    at = System.currentTimeMillis()
                )
            )
            if (result.isSuccess) {
                _printerStatus.value = PrinterStatus.READY
                _message.value = "Etiqueta enviada · ${product.nome}"
            } else {
                _printerStatus.value = PrinterStatus.ERROR
                _printerError.value = result.exceptionOrNull()?.message ?: "Erro"
                _message.value = "Falha na impressão"
            }
            _busy.value = false
            _savingLabel.value = null
        }
    }

    fun testPrint() {
        viewModelScope.launch {
            if (!ble.isConnected) {
                _message.value = "Conecte a impressora primeiro"
                return@launch
            }
            _busy.value = true
            _savingLabel.value = "Imprimindo teste..."
            _printerStatus.value = PrinterStatus.PRINTING
            val result = ble.write(EscPos.buildTest(uiState.value.settings.storeName), uiState.value.settings.printSpeed)
            _printerStatus.value = if (result.isSuccess) PrinterStatus.READY else PrinterStatus.ERROR
            _message.value = if (result.isSuccess) "Teste enviado" else "Falha no teste"
            _busy.value = false
            _savingLabel.value = null
        }
    }


    fun openLabelEditor() { _editingLabel.value = true }
    fun closeLabelEditor() { _editingLabel.value = false }

    /** Grava o layout editado só neste aparelho e passa a usá-lo na impressão. */
    fun saveLocalLabelLayout(json: String) {
        viewModelScope.launch {
            val s = uiState.value.settings
            repo.updateSettings(
                s.copy(
                    localLabelModelsJson = json,
                    useLocalLabel = true
                )
            )
            _message.value = "Layout salvo neste aparelho (não vai pro site)"
            _editingLabel.value = false
        }
    }

    /** Copia o modelo atual do servidor para o editor local. */
    fun pullLabelFromServer(onDone: (String?) -> Unit) {
        viewModelScope.launch {
            _savingLabel.value = "Baixando modelo do servidor…"
            val r = repo.syncFromCloud()
            _savingLabel.value = null
            val s = uiState.value.settings
            val server = s.labelModelsJson
            if (server.isBlank() || server == "[]") {
                _message.value = "Servidor sem modelo de etiqueta"
                onDone(null)
                return@launch
            }
            repo.updateSettings(
                s.copy(
                    localLabelModelsJson = server,
                    useLocalLabel = true
                )
            )
            _message.value = "Modelo do servidor copiado para este aparelho"
            onDone(server)
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Conexão automática com a última impressora
    // ─────────────────────────────────────────────────────────────

    private fun saveLastPrinter(address: String, name: String) {
        if (address.isBlank()) return
        prefs.edit()
            .putString(KEY_LAST_PRINTER_ADDRESS, address)
            .putString(KEY_LAST_PRINTER_NAME, name)
            .apply()
    }

    private fun hasBleConnectPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(
            getApplication<Application>(), Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Ao abrir o app: tenta conectar sozinho na última impressora usada.
     * Roda só uma vez por abertura (a MainActivity chama assim que a permissão
     * de Bluetooth estiver liberada). Se passar de [AUTO_CONNECT_WARN_MS] sem
     * conectar — ou se falhar — mostra o aviso para desligar/ligar a impressora
     * e, se não resolver, o Bluetooth.
     */
    fun autoConnectLastPrinter(force: Boolean = false) {
        if (autoConnectDone && !force) return
        val address = prefs.getString(KEY_LAST_PRINTER_ADDRESS, "").orEmpty()
        if (address.isBlank()) return                 // nunca conectou antes
        if (!hasBleConnectPermission()) return        // será chamado de novo quando liberar
        if (!ble.isBluetoothEnabled()) return
        if (ble.isConnected) return
        val device = ble.getDevice(address) ?: return

        autoConnectDone = true
        autoConnectJob?.cancel()
        autoConnectJob = viewModelScope.launch {
            _printerSlowWarning.value = false
            _printerStatus.value = PrinterStatus.CONNECTING
            _printerError.value = ""
            val watchdog = launch {
                delay(AUTO_CONNECT_WARN_MS)
                _printerSlowWarning.value = true
            }
            val result = ble.connect(device)
            watchdog.cancel()
            if (!isActive) return@launch              // usuário escolheu outra impressora na mão
            if (result.isSuccess) {
                _printerStatus.value = PrinterStatus.READY
                _printerName.value = ble.deviceName
                _printerSlowWarning.value = false
                _message.value = "Impressora pronta"
            } else {
                _printerStatus.value = PrinterStatus.ERROR
                _printerError.value = result.exceptionOrNull()?.message ?: "Falha"
                _printerSlowWarning.value = true
            }
        }
    }

    fun retryAutoConnect() {
        _printerSlowWarning.value = false
        autoConnectLastPrinter(force = true)
    }

    fun dismissPrinterWarning() { _printerSlowWarning.value = false }

    /** Procura atualização uma vez ao abrir, sem nenhum indicador na tela. */
    private fun checkAppUpdateSilently() {
        // Só ao abrir o app: procura Release novo e abre o popup se houver
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val info = try {
                AppUpdateChecker.check(app)
            } catch (_: Exception) {
                return@launch
            }
            _updateTag.value = info.latestTag
            _updateApkUrl.value = info.apkUrl
            _updateReleaseId.value = info.releaseId
            if (info.available) {
                _updateAvailable.value = true
                _updateMessage.value = info.reason.ifBlank {
                    "Nova versão ${info.latestTag} disponível"
                }
                // Popup na abertura
                _updateDialog.value = true
            } else {
                _updateAvailable.value = false
                if (info.error == null || info.reason.contains("atualizado", true)) {
                    AppUpdateInstaller.clearCache(app)
                }
            }
        }
    }

    /**
     * Baixa o APK da atualização detectada, mostrando o progresso no pill do
     * topo. Ao terminar, abre a janela "Instalar agora?".
     */
    private fun startUpdateDownload() {
        if (updateDownloadJob?.isActive == true) return
        // Já baixou nesta sessão: só pergunta de novo.
        if (_updateReadyPath.value != null) {
            _updateDialog.value = true
            return
        }
        val url = _updateApkUrl.value
        val tag = _updateTag.value
        if (url.isBlank()) return
        updateDownloadJob = viewModelScope.launch {
            _updateProgress.value = -1
            val r = AppUpdateInstaller.download(getApplication<Application>(), url, tag) { pct ->
                _updateProgress.value = pct
            }
            _updateProgress.value = null
            r.onSuccess { file ->
                _updateReadyPath.value = file.absolutePath
                _updateMessage.value = "Versão $tag baixada — pronta para instalar"
                // Lembra qual Release baixamos; a instalação é confirmada na próxima abertura
                AppUpdateChecker.markDownloaded(
                    getApplication(),
                    releaseId = _updateReleaseId.value,
                    tag = tag
                )
                _updateDialog.value = true
            }.onFailure { e ->
                _updateMessage.value = "Não foi possível baixar a atualização: ${e.message ?: "erro"}"
            }
        }
    }

    /** Botão de Ajustes: baixa a atualização (ou reabre a pergunta se já baixou). */
    fun downloadUpdate() = startUpdateDownload()

    fun dismissUpdateDialog() {
        _updateDialog.value = false
        // Não mostrar de novo o mesmo Release até sair um mais novo
        val id = _updateReleaseId.value
        if (id > 0L && _updateReadyPath.value == null) {
            AppUpdateChecker.markSkipped(getApplication(), id)
        }
    }

    /** Consulta GitHub Releases por atualização do APK. */
    fun checkAppUpdate() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _savingLabel.value = "Procurando atualização…"
            AppUpdateChecker.clearSkipped(getApplication())
            val info = AppUpdateChecker.check(getApplication())
            _savingLabel.value = null
            _updateAvailable.value = info.available
            _updateTag.value = info.latestTag
            _updateApkUrl.value = info.apkUrl
            _updateReleaseId.value = info.releaseId
            _updateMessage.value = when {
                info.available -> info.reason.ifBlank {
                    "Nova versão ${info.latestTag} (você: ${info.currentVersion})"
                }
                info.error != null -> info.error
                else -> info.reason.ifBlank {
                    "Sem atualização. App ${info.currentVersion}"
                }
            }
            if (info.available) {
                _message.value = "Atualização ${info.latestTag} disponível"
                _updateDialog.value = true
            }
        }
    }

    fun clearUpdateMessage() { _updateMessage.value = null }

    fun getBondedDevices(): List<BluetoothDevice> = ble.getBondedDevices()
    fun isBluetoothEnabled(): Boolean = ble.isBluetoothEnabled()

    private companion object {
        const val KEY_LAST_PRINTER_ADDRESS = "last_printer_address"
        const val KEY_LAST_PRINTER_NAME = "last_printer_name"
        /** Depois de quantos ms sem conectar aparece o aviso (entre 5 e 7 s). */
        const val AUTO_CONNECT_WARN_MS = 6_000L
    }
}
