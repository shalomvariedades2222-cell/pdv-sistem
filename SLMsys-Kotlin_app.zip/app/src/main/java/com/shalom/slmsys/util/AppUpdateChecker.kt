package com.shalom.slmsys.util

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import com.shalom.slmsys.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Detecta atualização no GitHub — SEM depender de você lembrar de mudar a versão no app.
 *
 * COMO O APP SABE QUAL VERSÃO ELE É (camada de identidade):
 *
 * 1. IMPRESSÃO DIGITAL DO APK: o app calcula o SHA-256 do próprio APK instalado
 *    e compara com o SHA-256 (digest) de cada APK anexado nos Releases do GitHub.
 *    Se bater, ele sabe EXATAMENTE de qual Release veio — mesmo que o
 *    versionName dentro do app esteja errado/esquecido.
 * 2. REGISTRO DE INSTALAÇÃO: quando você baixa pelo app e instala, o app grava
 *    qual Release era. Ao abrir de novo, confirma que a instalação aconteceu
 *    (o Android atualiza a "data da última atualização" do app) e passa a saber
 *    a versão. O registro vale só enquanto o app não for reinstalado por outra via.
 * 3. TAMANHO DO APK: último recurso, só quando o GitHub não informa o digest.
 *
 * Regra final: o app está atualizado se o Release ao qual ele pertence é o
 * mais recente publicado. Como o Release novo tem outro APK, ao instalar ele
 * passa a bater com o Release novo — o popup não volta a aparecer (sem loop).
 * O versionName do build.gradle é só um rótulo e não decide mais nada.
 */
object AppUpdateChecker {

    private const val PREFS = "slm_update_tracker"
    private const val KEY_SKIPPED_ID = "skipped_release_id"

    // Download feito, instalação ainda não confirmada
    private const val KEY_PENDING_ID = "pending_release_id"
    private const val KEY_PENDING_TAG = "pending_release_tag"
    private const val KEY_PENDING_AT = "pending_download_ms"

    // Release confirmado como o instalado (válido só para esta instalação)
    private const val KEY_INST_ID = "installed_release_id"
    private const val KEY_INST_TAG = "installed_release_tag"
    private const val KEY_INST_PKGTIME = "installed_pkg_time"

    // Cache do SHA-256 do APK instalado
    private const val KEY_HASH = "apk_sha256"
    private const val KEY_HASH_STAMP = "apk_sha256_stamp"

    /** Quem é o app instalado neste aparelho. */
    data class LocalIdentity(
        val versionName: String,
        val versionCode: Int,
        val buildTimeMs: Long,
        val installedAtMs: Long,
        val sha256: String,
        val sizeBytes: Long,
        /** Tag do Release de onde este APK veio ("" = ainda não vinculado). */
        val releaseTag: String
    ) {
        val shortId: String get() = if (sha256.isBlank()) "?" else sha256.take(8)

        /** Texto pronto para a tela de Ajustes. */
        fun label(): String {
            val main = if (releaseTag.isNotBlank())
                "Versão instalada: $releaseTag (identificada pelo GitHub)"
            else
                "Versão instalada: $versionName (ainda não vinculada a um Release — toque em Procurar atualização)"
            return main + "\n" +
                "APK: $versionName (cód. $versionCode) · build ${fmtDate(buildTimeMs)} · id $shortId"
        }
    }

    data class UpdateInfo(
        val available: Boolean,
        val latestTag: String = "",
        val latestName: String = "",
        val apkUrl: String = "",
        val body: String = "",
        val currentVersion: String = "",
        val currentCode: Int = 0,
        val remoteVersion: String = "",
        val remoteCode: Int = 0,
        val releaseId: Long = 0,
        val reason: String = "",
        val error: String? = null,
        /** Tag do Release que o app instalado foi identificado como sendo ("" = não identificado). */
        val installedTag: String = ""
    )

    private data class ReleaseCand(
        val id: Long,
        val tag: String,
        val name: String,
        val versionName: String,
        val versionCode: Int,
        val apkUrl: String,
        val body: String,
        val publishedMs: Long,
        val sizeBytes: Long,
        /** SHA-256 em minúsculas, sem o prefixo "sha256:" ("" se o GitHub não informou). */
        val digest: String
    )

    // ─────────────────────────── Identidade local ───────────────────────────

    /** Calcula (e guarda em cache) a identidade do APK instalado. Chame fora da thread principal. */
    fun localIdentity(context: Context): LocalIdentity {
        val (name, code) = installedVersion(context)
        val pkgTime = packageLastUpdateTime(context)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val apk = File(context.applicationInfo.sourceDir)
        val size = try { apk.length() } catch (_: Exception) { 0L }
        val stamp = "$pkgTime:$size"

        var hash = if (prefs.getString(KEY_HASH_STAMP, "") == stamp)
            prefs.getString(KEY_HASH, "").orEmpty() else ""
        if (hash.isBlank()) {
            hash = try { sha256Of(apk) } catch (_: Exception) { "" }
            if (hash.isNotBlank()) {
                prefs.edit().putString(KEY_HASH, hash).putString(KEY_HASH_STAMP, stamp).apply()
            }
        }
        val tag = if (prefs.getLong(KEY_INST_PKGTIME, -1L) == pkgTime)
            prefs.getString(KEY_INST_TAG, "").orEmpty() else ""

        return LocalIdentity(
            versionName = name,
            versionCode = code,
            buildTimeMs = BuildConfig.BUILD_TIME,
            installedAtMs = pkgTime,
            sha256 = hash,
            sizeBytes = size,
            releaseTag = tag
        )
    }

    private fun sha256Of(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** O Release [rel] tem um APK compatível com o instalado? (digest, ou tamanho se não houver digest) */
    private fun matchesInstalled(rel: ReleaseCand, local: LocalIdentity): Boolean {
        if (rel.digest.isNotBlank() && local.sha256.isNotBlank()) return rel.digest == local.sha256
        if (rel.sizeBytes > 0 && local.sizeBytes > 0) return rel.sizeBytes == local.sizeBytes
        return true
    }

    /** Descobre de qual Release o APK instalado veio. Null = não foi possível vincular. */
    private fun identifyInstalled(
        prefs: SharedPreferences,
        releases: List<ReleaseCand>,
        local: LocalIdentity
    ): ReleaseCand? {
        // 1) impressão digital idêntica → certeza
        if (local.sha256.isNotBlank()) {
            releases.firstOrNull { it.digest.isNotBlank() && it.digest == local.sha256 }
                ?.let { return it }
        }
        // 2) registro de instalação (só vale para esta instalação do app)
        if (prefs.getLong(KEY_INST_PKGTIME, -1L) == local.installedAtMs) {
            val id = prefs.getLong(KEY_INST_ID, 0L)
            val rel = releases.firstOrNull { it.id == id }
            // Se você trocou o APK dentro do mesmo Release, o registro deixa de valer.
            if (rel != null && matchesInstalled(rel, local)) return rel
        }
        return null
    }

    /** Se baixamos um Release e o app foi reinstalado depois, confirma que ele é o instalado. */
    private fun confirmPending(
        prefs: SharedPreferences,
        releases: List<ReleaseCand>,
        local: LocalIdentity
    ) {
        val pendingId = prefs.getLong(KEY_PENDING_ID, 0L)
        if (pendingId == 0L) return
        val downloadedAt = prefs.getLong(KEY_PENDING_AT, 0L)
        if (local.installedAtMs <= downloadedAt) return // ainda não instalou

        val rel = releases.firstOrNull { it.id == pendingId }
        val editor = prefs.edit()
        if (rel != null && matchesInstalled(rel, local)) {
            editor.putLong(KEY_INST_ID, rel.id)
                .putString(KEY_INST_TAG, rel.tag)
                .putLong(KEY_INST_PKGTIME, local.installedAtMs)
        }
        editor.remove(KEY_PENDING_ID).remove(KEY_PENDING_TAG).remove(KEY_PENDING_AT).apply()
    }

    private fun rememberInstalled(prefs: SharedPreferences, rel: ReleaseCand, local: LocalIdentity) {
        prefs.edit()
            .putLong(KEY_INST_ID, rel.id)
            .putString(KEY_INST_TAG, rel.tag)
            .putLong(KEY_INST_PKGTIME, local.installedAtMs)
            .apply()
    }

    // ─────────────────────────────── Checagem ───────────────────────────────

    fun check(context: Context): UpdateInfo {
        val local = localIdentity(context)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val skippedId = prefs.getLong(KEY_SKIPPED_ID, 0L)

        val repo = BuildConfig.GITHUB_REPO.trim()
        if (repo.isBlank() || repo == "OWNER/REPO" || !repo.contains("/")) {
            return UpdateInfo(
                available = false,
                currentVersion = local.versionName,
                currentCode = local.versionCode,
                installedTag = local.releaseTag,
                error = "GITHUB_REPO não configurado"
            )
        }

        return try {
            val releases = fetchReleases(repo)
            if (releases.isEmpty()) {
                return UpdateInfo(
                    available = false,
                    currentVersion = local.versionName,
                    currentCode = local.versionCode,
                    installedTag = local.releaseTag,
                    error = "Nenhum Release com APK no GitHub"
                )
            }

            confirmPending(prefs, releases, local)

            // O último Release é sempre o publicado mais recentemente (não o de "maior número").
            val best = releases.maxByOrNull { it.publishedMs } ?: releases.first()
            val installedRel = identifyInstalled(prefs, releases, local)
            if (installedRel != null) rememberInstalled(prefs, installedRel, local)
            val installedTag = installedRel?.tag ?: ""

            val upToDate = when {
                installedRel != null -> installedRel.id == best.id
                // Sem digest no GitHub e sem registro: APK do mesmo tamanho = mesmo APK.
                best.digest.isBlank() && best.sizeBytes > 0 && best.sizeBytes == local.sizeBytes -> true
                else -> false
            }

            // App não vinculado a Release, mas com versionName claramente MAIOR que o do
            // GitHub (você compilou algo novo e ainda não publicou): não oferece "downgrade".
            val localIsNewer = installedRel == null && !upToDate &&
                isVersionClearlyOlder(best.versionName, best.versionCode, local.versionName, local.versionCode)

            fun info(available: Boolean, reason: String) = UpdateInfo(
                available = available,
                latestTag = best.tag,
                latestName = best.name.ifBlank { best.tag },
                apkUrl = best.apkUrl,
                body = best.body,
                currentVersion = local.versionName,
                currentCode = local.versionCode,
                remoteVersion = best.versionName,
                remoteCode = best.versionCode,
                releaseId = best.id,
                reason = reason,
                installedTag = installedTag
            )

            when {
                upToDate -> info(
                    false,
                    "Já está atualizado · você está na versão ${best.tag} (id ${local.shortId})"
                )
                localIsNewer -> info(
                    false,
                    "Este app (${local.versionName}) é mais novo que o último Release (${best.tag}). " +
                        "Publique o APK novo no GitHub."
                )
                best.id == skippedId && skippedId != 0L -> info(
                    false,
                    "Você adiou a versão ${best.tag}. Toque em Procurar atualização para ver de novo."
                )
                else -> {
                    val sb = StringBuilder()
                    if (installedRel != null) {
                        sb.append("Você está na versão ${installedRel.tag}.\n")
                    } else {
                        sb.append(
                            "Não consegui ligar o app instalado (${local.versionName}, id ${local.shortId}) " +
                                "a nenhum Release — ele difere do último do GitHub.\n"
                        )
                    }
                    sb.append("Nova no GitHub: ${best.tag} · publicada em ${fmtDate(best.publishedMs)}")
                    info(best.apkUrl.isNotBlank(), sb.toString())
                }
            }
        } catch (e: Exception) {
            UpdateInfo(
                available = false,
                currentVersion = local.versionName,
                currentCode = local.versionCode,
                installedTag = local.releaseTag,
                error = e.message ?: "Falha ao checar atualização"
            )
        }
    }

    /** Chamado quando o APK do Release termina de baixar. A instalação é confirmada no próximo check. */
    fun markDownloaded(context: Context, releaseId: Long, tag: String) {
        if (releaseId <= 0L) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_PENDING_ID, releaseId)
            .putString(KEY_PENDING_TAG, tag)
            .putLong(KEY_PENDING_AT, System.currentTimeMillis())
            .remove(KEY_SKIPPED_ID)
            .apply()
    }

    /** Usuário tocou em "Depois" — não mostrar de novo o mesmo Release. */
    fun markSkipped(context: Context, releaseId: Long) {
        if (releaseId <= 0L) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_SKIPPED_ID, releaseId)
            .apply()
    }

    fun clearSkipped(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_SKIPPED_ID)
            .apply()
    }

    private fun installedVersion(context: Context): Pair<String, Int> {
        return try {
            val pm = context.packageManager
            val pkg = context.packageName
            val info = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            val name = (info.versionName ?: BuildConfig.VERSION_NAME).removePrefix("v").trim()
            val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt()
            else @Suppress("DEPRECATION") info.versionCode
            name to code
        } catch (_: Exception) {
            BuildConfig.VERSION_NAME.removePrefix("v").trim() to BuildConfig.VERSION_CODE
        }
    }

    private fun packageLastUpdateTime(context: Context): Long {
        return try {
            val pm = context.packageManager
            val pkg = context.packageName
            val info = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            info.lastUpdateTime
        } catch (_: Exception) {
            0L
        }
    }

    private fun fmtDate(ms: Long): String =
        if (ms <= 0L) "?" else SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(ms))

    private fun fetchReleases(repo: String): List<ReleaseCand> {
        val url = URL("https://api.github.com/repos/$repo/releases?per_page=20")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "SLMsys-Android")
            setRequestProperty("Cache-Control", "no-cache")
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optString("message").ifBlank { "HTTP $code" }
            } catch (_: Exception) {
                "HTTP $code"
            }
            throw Exception(
                if (msg.contains("rate limit", true))
                    "Limite da API do GitHub. Tente em alguns minutos."
                else "GitHub: $msg"
            )
        }

        val arr = JSONArray(text)
        val list = mutableListOf<ReleaseCand>()
        for (i in 0 until arr.length()) {
            val json = arr.optJSONObject(i) ?: continue
            if (json.optBoolean("draft", false)) continue
            if (json.optBoolean("prerelease", false)) continue
            val tag = json.optString("tag_name").trim()
            if (tag.isBlank()) continue
            val assets = json.optJSONArray("assets") ?: continue
            var apkUrl = ""
            var apkSize = 0L
            var apkDigest = ""
            for (j in 0 until assets.length()) {
                val a = assets.optJSONObject(j) ?: continue
                if (a.optString("name").lowercase().endsWith(".apk")) {
                    apkUrl = a.optString("browser_download_url")
                    apkSize = a.optLong("size", 0L)
                    val d = a.optString("digest").trim().lowercase()
                    apkDigest = if (d.startsWith("sha256:")) d.removePrefix("sha256:") else ""
                    break
                }
            }
            if (apkUrl.isBlank()) continue

            val body = json.optString("body")
            val (vName, vCode) = parseVersion(tag, body)
            list += ReleaseCand(
                id = json.optLong("id", 0L),
                tag = tag.removePrefix("v"),
                name = json.optString("name").ifBlank { tag },
                versionName = vName,
                versionCode = vCode,
                apkUrl = apkUrl,
                body = body,
                publishedMs = parseIso(json.optString("published_at")),
                sizeBytes = apkSize,
                digest = apkDigest
            )
        }
        return list
    }

    private fun parseIso(iso: String): Long {
        if (iso.isBlank()) return 0L
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            // published_at pode ter fração: 2026-09-24T12:44:40Z
            val clean = iso.replace(Regex("""\.\d+Z$"""), "Z")
            fmt.parse(clean)?.time ?: 0L
        } catch (_: Exception) {
            try {
                val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US)
                fmt.parse(iso)?.time ?: 0L
            } catch (_: Exception) {
                0L
            }
        }
    }

    private fun parseVersion(tag: String, body: String): Pair<String, Int> {
        val clean = tag.removePrefix("v").trim()
        var code = 0
        var name = clean

        // Antes exigia que a tag inteira fosse só o número (ex: "1.2.3"), então tags
        // como "release-1.2.3" ou "App v1.2.3" caíam no caso "versão desconhecida" e
        // o Release virava invisível pro app. Agora procura um trecho tipo "1.2.3"
        // em qualquer lugar da tag, mesmo com prefixo/sufixo.
        val exact = Regex("""^\d+(\.\d+)*([+\-_]\d+)?$""").matches(clean)
        val embedded = Regex("""\d+(?:\.\d+){1,3}""").find(clean)
        if (exact) {
            val plus = Regex("""^(.+?)[+\-_](\d+)$""").find(clean)
            if (plus != null) {
                name = plus.groupValues[1]
                code = plus.groupValues[2].toIntOrNull() ?: 0
            }
        } else if (embedded != null) {
            name = embedded.value
        } else {
            // Tag tipo "App Android" — sem número nenhum; tenta no corpo da descrição
            name = ""
            val mBody = Regex("""versionName\s*[:=]\s*([\d.]+)""", RegexOption.IGNORE_CASE).find(body)
            if (mBody != null) name = mBody.groupValues[1]
        }

        if (code == 0 && body.isNotBlank()) {
            val m = Regex("""versionCode\s*[:=]\s*(\d+)""", RegexOption.IGNORE_CASE).find(body)
            if (m != null) code = m.groupValues[1].toIntOrNull() ?: 0
        }
        return name to code
    }

    private fun versionParts(s: String): IntArray {
        if (s.isBlank()) return intArrayOf(0)
        val list = s.split(".", "-", "_")
            .mapNotNull { part -> part.filter { it.isDigit() }.toIntOrNull() }
        return if (list.isEmpty()) intArrayOf(0) else list.toIntArray()
    }

    private fun compareParts(a: IntArray, b: IntArray): Int {
        val n = maxOf(a.size, b.size)
        for (i in 0 until n) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    private fun isVersionClearlyOlder(
        remoteName: String,
        remoteCode: Int,
        localName: String,
        localCode: Int
    ): Boolean {
        if (remoteName.isBlank()) return false
        val byName = compareParts(versionParts(remoteName), versionParts(localName))
        if (byName < 0) return true
        if (byName > 0) return false
        if (remoteCode > 0 && localCode > 0) return remoteCode < localCode
        return false
    }
}
