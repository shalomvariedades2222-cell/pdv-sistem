package com.shalom.slmsys.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Baixa o APK da atualização DENTRO do app e chama o instalador do Android,
 * sem abrir navegador.
 */
object AppUpdateInstaller {

    private const val DIR = "updates"

    /** Android 8+ exige que o usuário libere "instalar apps desconhecidos" para o SLMsys. */
    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            context.packageManager.canRequestPackageInstalls()

    /**
     * Abre o instalador do Android para o APK. Se o app ainda não tem permissão
     * de instalar, abre a tela para liberar e devolve false (o usuário volta e
     * toca em Instalar de novo).
     */
    fun installOrAskPermission(context: Context, apk: File): Boolean {
        if (!canInstall(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            )
            if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    /** Apaga APKs antigos guardados (chamado quando o app já está atualizado). */
    fun clearCache(context: Context) {
        try {
            File(context.cacheDir, DIR).deleteRecursively()
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun isValidApk(context: Context, file: File): Boolean = try {
        val info = context.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
        info != null && info.packageName == context.packageName
    } catch (_: Exception) {
        false
    }

    /**
     * Baixa o APK para o cache do app. [onProgress] recebe 0..100
     * (não é chamado se o servidor não informar o tamanho).
     */
    suspend fun download(
        context: Context,
        url: String,
        tag: String,
        onProgress: (Int) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.cacheDir, DIR).apply { mkdirs() }
            val safeTag = tag.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(dir, "slmsys-$safeTag.apk")
            val part = File(dir, "slmsys-$safeTag.apk.part")

            // limpa versões antigas
            dir.listFiles()?.filter { it != target }?.forEach { it.delete() }

            // Sempre baixa de novo: você pode ter trocado o APK dentro do mesmo Release,
            // e reaproveitar o arquivo antigo instalaria a versão errada.
            target.delete()
            part.delete()

            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "SLMsys-Android")
            }
            try {
                if (conn.responseCode !in 200..299) {
                    return@withContext Result.failure(Exception("HTTP ${conn.responseCode}"))
                }
                val total = conn.contentLengthLong
                var done = 0L
                var lastPct = -1
                conn.inputStream.use { input ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt().coerceIn(0, 100)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                }
                if (total > 0 && done != total) {
                    part.delete()
                    return@withContext Result.failure(Exception("download incompleto"))
                }
            } finally {
                conn.disconnect()
            }

            if (!part.renameTo(target) || !isValidApk(context, target)) {
                target.delete()
                part.delete()
                return@withContext Result.failure(Exception("arquivo baixado não é um APK válido do SLMsys"))
            }
            Result.success(target)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
